import scala.io.StdIn._
object Answer6 {
def main(args: Array[String]){
    val favoriteMovie = readLine("What is your favorite movie of all times?");
    println(s"$favoriteMovie is totally awesome!");
	}
	}
